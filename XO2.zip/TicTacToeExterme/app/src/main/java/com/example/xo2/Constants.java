package com.example.xo2;

class Constants {
    public static boolean isCodeMaker = true;
    public static boolean codeFound = false;
    public static boolean checkTemp = true;
    public static String keyValue = "null";
    public static String code = "null";
}
