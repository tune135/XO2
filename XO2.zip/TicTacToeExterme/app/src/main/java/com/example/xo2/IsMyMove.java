package com.example.xo2;

public class IsMyMove {
    public static boolean isMyMove = Constants.isCodeMaker;
}
